#import "MGLFoundation.h"
#import "MGLMapView.h"
#import "MGLAnnotation.h"
#import "MGLAnnotationView.h"
NS_ASSUME_NONNULL_BEGIN
	
MGL_EXPORT
@interface MGLMarker : NSObject <MGLAnnotation>

/** Convenience constructor for a default marker. */
+ (instancetype)markerWithPosition:(CLLocationCoordinate2D)position;
-(instancetype)initWithCoordinate:(CLLocationCoordinate2D)coordinate title:(NSString * _Nullable )title subtitle:(NSString * _Nullable )subtitle;
-(instancetype)initWithCoordinate:(CLLocationCoordinate2D)coordinate reuseIdentifier:(NSString * _Nullable)reuseIdentifier;
/** ReuseIdentifier of marker */
@property (nonatomic, strong, nullable) NSString *reuseIdentifier;
/** Marker position. Change this value to update marker position, support UIView animation*/
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
/** Title text, shown in the callout when selected. */
@property (nonatomic, copy, nullable) NSString *title;
/** Subtitle text, shown beneath the title in the callout when selected. */
@property (nonatomic, copy, nullable) NSString *subtitle;
/**
 * The map this overlay is on. Setting this property will add the overlay to the map. Setting it to
 * nil removes this overlay from the map. An overlay may be active on at most one map at any given
 * time.
 */
@property (weak, nonatomic) MGLMapView *map;
/**
 * Sets the rotation of the marker in degrees clockwise about the marker's anchor point. The axis of
 * rotation is perpendicular to the marker. A rotation of 0 corresponds to the default position of
 * the marker.
 * Support UIView animation
 */
@property (assign, nonatomic) float rotation;
/**
 * Sets the opacity of the marker, between 0 (completely transparent) and 1 (default) inclusive.
 * Support UIView animation
 */
@property (assign, nonatomic) float opacity;
/**
 * Marker view to render. If left nil, falls back to the |icon| property instead.
 *
 * Supports animation of all animatable properties of UIView, except |frame| and |center|. Changing
 * these properties or their corresponding CALayer version, including |position|, is not supported.
 *
 * Note that the view behaves as if |clipsToBounds| is set to YES, regardless of its actual value.
 */
@property (strong, nonatomic) UIView *iconView;
/**
 * Marker icon to render. If left nil, uses a default SDK place marker.
 */
@property (strong, nonatomic) UIImage *icon;

@end

NS_ASSUME_NONNULL_END
