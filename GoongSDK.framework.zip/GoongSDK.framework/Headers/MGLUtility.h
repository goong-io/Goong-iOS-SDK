#import "MGLFoundation.h"
#import <CoreLocation/CoreLocation.h>
NS_ASSUME_NONNULL_BEGIN
/**
 Geometry helper
 */
MGL_EXPORT
@interface MGLUtility : NSObject
/**
 Return an array of CLLocation
 
 @param geometry The geometry string to be decoded
 @param precision The decode precision (5 digit precision used by Google)
 */
+ (NSArray <CLLocation *>*_Nonnull)decodeGeometry:(NSString *_Nonnull)geometry precision:(int)precision;
/**
 Return an array of CLLocation
 
 @param geometry The geometry string to be decoded
 @note Default precision is 5
 */
+ (NSArray <CLLocation *>*_Nonnull)decodeGeometry:(NSString *_Nonnull)geometry;
@end

NS_ASSUME_NONNULL_END
