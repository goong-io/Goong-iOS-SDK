#import <Foundation/Foundation.h>

#import "MGLFoundation.h"

NS_ASSUME_NONNULL_BEGIN

/**
 The `GoongAccountManager` object provides a global way to set a Goong API access
 token.
 */
MGL_EXPORT
@interface GoongAccountManager : NSObject

#pragma mark Authorizing Access

/**
 The Goong access token
 used by all instances of `MGLMapView` in the current application.
 Setting this property to a value of `nil` has no effect.
 */
@property (class, nullable) NSString *accessToken;


@end

NS_ASSUME_NONNULL_END
