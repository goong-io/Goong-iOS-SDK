#import "MGLFoundation.h"
#import "MGLMapView.h"
NS_ASSUME_NONNULL_BEGIN
/**
 * MGLMapView (Animation) offers several animation helper methods.
 */
MGL_EXPORT
@interface MGLMapView (Animation)

/**
 * Changes only the location of the camera (i.e., from the current
 * location to |location|).
 */
- (void)animateToLocation:(CLLocationCoordinate2D)location;

/**
 * Changes only the bearing of the camera (in degrees). Zero
 * indicates true north.
 */
- (void)animateToBearing:(CLLocationDirection)bearing;

/**
 * Cut changes only the viewing angle of the camera (in degrees). This
 * value will be clamped to a minimum of zero (i.e., facing straight down) and between 30 and 45
 * degrees towards the horizon, depending on the relative closeness to the earth.
 */
- (void)animateToViewingAngle:(double)viewingAngle;

/**
 * The zoom increment is 1.0.
 */
- (void)zoomIn;

/**
 * The zoom increment is -1.0.
 */
- (void)zoomOut;
/**
 * Applies |camera| to the current camera with animation
 */
- (void)animateWithCameraUpdate:(MGLMapCamera *)cameraUpdate;

@end

NS_ASSUME_NONNULL_END
