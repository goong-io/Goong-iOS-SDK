#import "MGLFoundation.h"
#import "MGLMapView.h"
NS_ASSUME_NONNULL_BEGIN

MGL_EXPORT
@interface GoongPolyline : NSObject
/**
 * Convenience constructor for GoongPolyline for a particular path. Other properties will have
 * default values.
 */
+(instancetype)polylineWithPath:(NSString *)path;
/**
 Creates and returns an `GoongPolyline` object from the specified set of
 coordinates.
 
 @param coords The array of coordinates defining the shape. The data in this
 array is copied to the new object.
 @param count The number of items in the `coords` array.
 @return A new `Goongpolyline` object.
 */
+ (instancetype)polylineWithCoordinates:(const CLLocationCoordinate2D *)coords count:(int)count;

/**
 * The map this overlay is on. Setting this property will add the overlay to the map. Setting it to
 * nil removes this overlay from the map. An overlay may be active on at most one map at any given
 * time.
 *
 * @note Because the style loads asynchronously, you should set this property after map's style has finish loading in the
 * `-[MGLMapViewDelegate mapView:didFinishLoadingStyle:]` or
 * `-[MGLMapViewDelegate mapViewDidFinishLoadingMap:]` method
 */
@property (weak, nonatomic) MGLMapView *map;
/**
 * The path that describes this polyline.
 * Set this property to other value will change the polyline shape
 */
@property (strong, nonatomic, nullable) NSString *path;
/**
 * The width of the line in screen points. Defaults to 1.
 * Set this property to other value will change the polyline width animatedly
 */
@property (nonatomic, assign) CGFloat strokeWidth;
/**
 * The UIColor used to render the polyline. Defaults to [UIColor blueColor].
 * Set this property to other value will change the polyline color animatedly
 */
@property (nonatomic, strong, nullable) UIColor *strokeColor;
/**
 * The opacity of the line from 0 to 1. Defaults to 1
 * Set this property to other value will change the polyline opacity animatedly
 */
@property (nonatomic, assign) CGFloat opacity;


@end

NS_ASSUME_NONNULL_END
